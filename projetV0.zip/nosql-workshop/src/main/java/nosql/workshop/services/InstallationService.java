package nosql.workshop.services;

import com.google.inject.Singleton;

/**
 * Service permettant de manipuler les installations sportives.
 */
@Singleton
public class InstallationService {

}
